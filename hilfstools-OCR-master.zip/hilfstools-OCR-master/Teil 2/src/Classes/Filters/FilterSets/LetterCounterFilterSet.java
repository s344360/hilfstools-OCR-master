package Classes.Filters.FilterSets;

import Classes.Data.DataLine;
import Classes.Filters.FilterSet;

public class LetterCounterFilterSet extends FilterSet<DataLine> {
	public LetterCounterFilterSet() {

	}
}