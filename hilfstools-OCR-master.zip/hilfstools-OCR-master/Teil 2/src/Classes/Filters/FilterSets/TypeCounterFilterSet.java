package Classes.Filters.FilterSets;

import Classes.Data.DataLine;
import Classes.Filters.FilterSet;

public class TypeCounterFilterSet extends FilterSet<DataLine> {
	public TypeCounterFilterSet() {
	}
}