package Classes.Logic;

import java.util.ArrayList;
import java.util.List;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfPoint;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;

public class FindContour {
	public static void main(String args[]) {
		// Load the library

//		System.loadLibrary("opencv_java245");
//		Mat eyeMat = faceMat.submat(eyesArray[j]); // This is a gray image
//		Imgproc.GaussianBlur(eyeMat, eyeMat, new Size(9, 9), 2, 2);
//		Imgproc.threshold(eyeMat, eyeMat, 30, 255, Imgproc.THRESH_BINARY);
//		List<MatOfPoint> contours = new ArrayList<MatOfPoint>();
//		Mat hierarchy = new Mat();
//		Imgproc.findContours(eyeMat, contours, hierarchy, Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_NONE);
//		double arcLength(InputArray curve, boolean closed);
	}

}
